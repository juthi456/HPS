<header>
    <nav style="display:flex;
    justify-content:space-between;align-items:center;margin-top:3rem;margin-bottom:3rem;">
        <a style="display:flex;align-items:center;gap:20px;text-decoration:none;color:black;"
            href="../view/dashboard.php">
            <h1 style="color:#3498DB;font-size:30px">HMS.</h1>
            <h1 style="color:#3498DB;font-size:30px">Receptionist</h1>
        </a>
        <ul style="display:flex;justify-content:space-between;list-style-type:none;align-items:center;">
            <li style="text-decoration:none;color:black;padding-right:10px;padding-left:10px;">

            </li>
            <li style="text-decoration:none;color:black;padding-right:10px;padding-left:10px;">
                <a style="text-decoration:none;color:black;" href="../control/profileAction.php">
                    Profile
                </a>
            </li>
            <li style="text-decoration:none;color:black;padding-right:10px;padding-left:10px;">
                <a style="text-decoration:none;color:black;" href="../view/changePassword.php">
                    Change Password
                </a>
            </li>
            <li style="text-decoration:none;color:black;padding-right:10px;padding-left:10px;">
                <a style="text-decoration:none;color:black;" href="../view/viewHistory.php">
                    Patient History
                </a>
            </li>
            <li style="text-decoration:none;color:black;padding-right:10px;padding-left:10px;">
                <a style="text-decoration:none;color:black;" href="../view/notice.php">
                    Notice
                </a>
            </li>
            <li style="text-decoration:none;color:black;padding-right:10px;padding-left:10px;">
                <a style="text-decoration:none;color:black;" href="../control/logOut.php">
                    <button style="color:#2C3539;padding:10px;padding: 10px;border: none;border-radius: 30px;">
                        Log Out
                    </button>
                </a>
            </li>
        </ul>
    </nav>
</header>