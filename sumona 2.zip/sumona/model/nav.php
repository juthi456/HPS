<nav style="display:flex;
justify-content:space-between;align-items:center;">
    <h1 style="color:#3498DB;font-size:30px">HMS.</h1>
    <ul style="display:flex;
justify-content:space-between;
list-style-type:none;">
        <li style="text-decoration:none;text-color:black;padding-right:10px;padding-left:10px;"><a style="text-decoration:none;" href="../view/signUp.php"><button style="color:#2C3539;padding:10px;border-radious:50%;">Sign Up</button></a></li>
        <li style="text-decoration:none;text-color:black;padding-right:10px;padding-left:10px;"><a style="text-decoration:none;" href="../view/logIn.php"><button style="color:#2C3539;padding:10px;border-radious:50%;">Log In</button></a></li>
    </ul>
</nav>
