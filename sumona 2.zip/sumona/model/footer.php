<footer style="margin-top:4rem">
    <p style="text-align:center;">copyright © 2024</p>
</footer>